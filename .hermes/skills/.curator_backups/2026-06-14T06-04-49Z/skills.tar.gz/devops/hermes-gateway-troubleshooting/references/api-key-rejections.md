## API Key Rejection Troubleshooting

If the logs show `gateway.platforms.api_server: API server rejected invalid API key`:

1. **Synchronize Keys**: 
   - Get the valid `API_SERVER_KEY` from `~/.hermes/.env`.
   - Ensure it is set as `API_SERVER_KEY=<key_value>` in your project's `.env` (e.g., `~/hermes-workspace/.env`).

2. **Verify Configuration**:
   - For backend services (Gateway), ensure `API_SERVER_ENABLED=true` and the key matches the one in `.env`.
   - For the Workspace/Dashboard, the `API_SERVER_KEY` must be correctly injected into the production start command or `.env` file.

3. **Restart Service**:
   You MUST stop the old process before starting the new one to avoid `EADDRINUSE` port collisions:
   `pkill -9 -f server-entry.js`
