---
name: hermes-gateway-troubleshooting
description: "Workflow for diagnosing and fixing gateway startup and connectivity issues."
---

# Hermes Gateway Troubleshooting

If the gateway fails to start or the workspace cannot connect, follow this sequence:

## 1. Diagnostics
- Check status: `hermes gateway status`
- Check logs: `~/.hermes/logs/gateway.log`
- Check active ports: `ss -tulpn | grep :8642`
- Verify system service: `sudo hermes gateway restart --system`

## 2. Common Pitfalls
- **Token Conflicts**: If "bot token already in use" occurs, use `ps -ef | grep hermes` to find lingering PID, then `kill -9 <PID>`.
- **Deprecated Config**: Check `~/.hermes/.env` for deprecated settings (e.g., `TERMINAL_CWD`) that block startup. Move these to `config.yaml` and remove from `.env`.
- **Port In Use**: Check if `vite` or other processes are hogging workspace ports (3000). Use `ss` and `kill -9` if necessary.
- **API Key Rejection**: If logs indicate "API server rejected invalid API key" (common in production/workspace setups), check that the gateway service and the workspace application are synced. See `references/api-key-rejections.md` for specific troubleshooting steps.

## 4. Persistent Workspace Configuration (Troubleshooting)
If the workspace repeatedly crashes with Exit Code 137 (OOM) or port collisions, avoid `npm run start` in production. Instead, run the server directly with manual memory limits:

```bash
cd ~/hermes-workspace/
NODE_ENV=production HOST=0.0.0.0 PORT=3000 HERMES_ALLOW_INSECURE_REMOTE=1 COOKIE_SECURE=0 \
  node --max-old-space-size=1024 server-entry.js
```
*   **Memory:** `--max-old-space-size=1024` prevents the process from triggering OOM killer in restricted environments.
*   **Networking:** `HOST=0.0.0.0` and `HERMES_ALLOW_INSECURE_REMOTE=1` are required for remote access (Tailscale/LAN) when running outside standard electron containers.
*   **Port Collision:** If `EADDRINUSE`, check `ss -tulpn | grep :3000` to identify and kill the existing node processes (`kill -9 <PID>`).

