---
name: hg-github-sync
description: Syncs critical configuration, skills, and memory to the GitHub repository for machine-agnostic survival.
---

# Skill: hg-github-sync

## Objective
Ensures system state persistence (Memory, User Config, Skills) by pushing to the GitHub repository.

## Scope of Sync
1. `/home/fabianogori/user.md`
2. `~/.hermes/skills/`
3. `~/.hermes/memories/`
4. `~/.hermes/agent_identity.md`

## Workflow
1. **Gather:** Identify changes in local configuration files.
2. **Stage:** Run `git add .` in the project root.
3. **Commit:** Execute `git commit -m "Automated System Sync: $(date -u)"`.
4. **Push:** Execute `git push origin main`.

## Integration
- Triggered by daily cron.
- Ensures recovery of the "Hg" personality and operational system after a machine swap.

## Pitfalls
- Ensure git is initialized in the target directory (check for `.git` and run `git init` if missing).
- **Verify Repository Integrity:** Before staging, confirm the repository is healthy and inside a valid work tree using `git rev-parse --is-inside-work-tree`. If this returns false despite the existence of `.git`, the index is likely corrupted; avoid destructive `reset --hard` operations without a backup.
- Empty commits result in no push; script handles this via logic check.
- **Authentication/Connectivity:** If git operations fail:
    1. Verify remote URL: Check `git remote -v`. Ensure it points to the correct `git@github.com:...` (SSH) address. Use `git remote set-url origin git@github.com:fabianogori/fabianogori.git` if needed.
    2. Verify SSH connectivity: `ssh -T git@github.com`.
    3. If 'Permission denied (publickey)':
        a. Verify `ssh-agent` is running and the identity is added (`ssh-add -l`).
        b. Ensure the public key `~/.ssh/id_ed25519.pub` is registered in GitHub account settings or as a Repository Deploy Key.
        c. If SSH fails, attempt `gh` CLI fallback (requires authenticated `gh` CLI with 'repo' scope):
            `git remote set-url origin https://github.com/fabianogori/fabianogori.git`
    4. If 'Host key verification failed', ensure `~/.ssh/known_hosts` contains the GitHub public keys. If the file is missing or corrupted, generate/append with `ssh-keyscan github.com >> ~/.ssh/known_hosts`.
    5. If SSH keys are correctly generated but still fail: Ensure the public key `~/.ssh/id_ed25519.pub` (or equivalent) is registered in the GitHub repository's Deploy Keys or SSH settings.
- **Large File Handling:** If the synchronization fails due to large files (e.g., git objects > 100MB), do NOT attempt to force push. Use manual file exclusion or Git LFS.
- **Troubleshooting Sequence:** If `git push` fails, run `ssh -T git@github.com` first to verify the identity/key pair connectivity before attempting to change remotes or verify git configs.

- **Git Corruption:** If index or object corruption occurs, consult `references/git-corruption-recovery.md` before attempting repairs. Do NOT attempt complex repair scripts without a clear recovery plan, as it causes loss of commit history. 
- **Style/Formatting Preference:** All communications, documentation, and agent outputs must adhere to the FABI Tactical System (zero-fluff, highly structured, scannable, Houston time anchor). This must be reflected in the commit messages and any generated documentation synced to the repo.
