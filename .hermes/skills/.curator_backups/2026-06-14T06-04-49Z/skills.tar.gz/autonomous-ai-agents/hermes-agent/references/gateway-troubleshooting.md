# Gateway Troubleshooting

The Hermes Gateway often enters a restart loop if manual processes and the system service conflict over the same port (8642) or credentials (Telegram Token).

## Resolution Sequence
1. **Stop Conflict:** Use `sudo systemctl stop hermes-gateway` and `sudo pkill -f "hermes gateway"` to ensure no processes are holding resources.
2. **Synchronize Config:**
   - In `~/.hermes/config.yaml`:
     ```yaml
     gateway:
       api_server_enabled: true
       api_server_host: 127.0.0.1
       api_server_port: 8642
     ```
   - In `~/.hermes/.env`:
     ```bash
     API_SERVER_ENABLED=true
     API_SERVER_KEY=secret_key_12345
     ```
3. **Restart Service:** `sudo systemctl restart hermes-gateway`.
4. **Verify Binding:** `ss -tulpn | grep :8642`.

## Workspace Integration
Ensure your `hermes-workspace/.env` has:
`HERMES_API_URL=http://127.0.0.1:8642`
`API_SERVER_KEY=secret_key_12345`
